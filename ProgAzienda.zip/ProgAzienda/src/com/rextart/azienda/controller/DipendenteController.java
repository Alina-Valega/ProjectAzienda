package com.rextart.azienda.controller;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.annotation.ManagedBean;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.persistence.Column;

import com.rextart.azienda.dao.DipendenteDao;
import com.rextart.azienda.dao.impl.DipartimentoDaoImpl;
import com.rextart.azienda.dao.impl.DipendenteDaoImpl;
import com.rextart.azienda.entity.Dipartimento;
import com.rextart.azienda.entity.Dipendente;

//import jakarta.inject.Named;

@SessionScoped
@ManagedBean
public class DipendenteController{
	
	DipendenteDaoImpl odb = new DipendenteDaoImpl(); 
	
	private int idDipendente;
	private String nomeDipendente;
	private String cognomeDipendente;
	private Date dataAssunzione;
	private float salario;

	
	public int getIdDipendente() {
		return idDipendente;
	}

	public void setIdDipendente(int idDipendente) {
		this.idDipendente = idDipendente;
	}

	public String getNomeDipendente() {
		return nomeDipendente;
	}

	public void setNomeDipendente(String nomeDipendente) {
		this.nomeDipendente = nomeDipendente;
	}

	public String getCognomeDipendente() {
		return cognomeDipendente;
	}

	public void setCognomeDipendente(String cognomeDipendente) {
		this.cognomeDipendente = cognomeDipendente;
	}

	public Date getDataAssunzione() {
		return dataAssunzione;
	}

	public void setDataAssunzione(Date dataAssunzione) {
		this.dataAssunzione = dataAssunzione;
	}

	public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		this.salario = salario;
	}

	// Method To Fetch The Existing List From The Database
	public List dipendentiListFromDb() {
		return odb.getAllDipendentiDetails();
	}
	
	// Method To Add New Dipendente To The Database
	public String addNewDipendente(String nomeDipendente, String cognomeDipendente, float salario, Date dataAssunzione) {
		return DipendenteDaoImpl.createNewDipendente(nomeDipendente, cognomeDipendente, dataAssunzione, salario);
	}
	
	//Method to delete from the db
		public String deleteDipendente(int idDipendente) {
			return DipendenteDaoImpl.deleteDipendente(idDipendente);
		}
	
		
	//Method to update
		public String updateDipendente(int idDipendente, String nomeDipendente, String cognomeDipendente, float salario, Date dataAssunzione) {
		
			return DipendenteDaoImpl.updateDipendente(idDipendente, nomeDipendente, cognomeDipendente, dataAssunzione, salario);
		}

	

}
