package com.rextart.azienda.controller;

import java.util.List;

import javax.annotation.ManagedBean;

import com.rextart.azienda.dao.impl.DipartimentoDaoImpl;
import com.rextart.azienda.entity.Dipartimento;

@ManagedBean
public class DipartimentoController {

	private int idDipartimento;
	private String nomeDipartimento;
	DipartimentoDaoImpl db = new DipartimentoDaoImpl();

	public int getIdDipartimento() {
		return idDipartimento;
	}

	public void setIdDipartimento(int idDipartimento) {
		this.idDipartimento = idDipartimento;
	}

	public String getNomeDipartimento() {
		return nomeDipartimento;
	}

	public void setNomeDipartimento(String nomeDipartimento) {
		this.nomeDipartimento = nomeDipartimento;
	}

	// Method To Fetch The Existing List From The Database
	public List dipartimentoListFromDb() {
		return db.getAllDipartimenti();
	}

	// Method To Add New Dipartimento To The Database
	public String addNewDipartimento(String nomeDipartimento) {
		return DipartimentoDaoImpl.createNewDipartimento(Dipartimento.getNomeDipartimento());
	}

	// Method To Delete From The Database
	public String deleteDipartimentoById(int idDipartimento) {
		return DipartimentoDaoImpl.deleteDipartimentoById(idDipartimento);
	}

	// Method To Update
	public String updateDipartimento(int idDipartimento, String nomeDipartimento) {
		return DipartimentoDaoImpl.updateDipartimento(idDipartimento, nomeDipartimento);
	}
}
