package com.rextart.azienda.dao;

import java.util.List;

import com.rextart.azienda.entity.Dipartimento;

public interface DipartimentoDao {

	public List<Dipartimento> getAllDipartimenti();

	public Dipartimento getdipartimento(int idDipartimeno);

	public static String updateDipartimento(Dipartimento dipartimento) {
		return null;
	}

	public static String deleteDipartimento(int IdDipartimento) {
		return null;
	}

}
