package com.rextart.azienda.dao.impl;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.rextart.azienda.dao.DipartimentoDao;
import com.rextart.azienda.entity.Dipartimento;

public class DipartimentoDaoImpl implements DipartimentoDao {

	private static final String PERSISTENCE_UNIT_NAME = "Azienda";
	public static EntityManager em = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME)
			.createEntityManager();
	public static EntityTransaction transactionObj = em.getTransaction();

	@Override
	public List<Dipartimento> getAllDipartimenti() {

		return em.createQuery("from Dipartimento").getResultList();
	}

	@Override
	public Dipartimento getdipartimento(int idDipartimento) {
		Dipartimento dipartimento = em.find(Dipartimento.class, idDipartimento);

		return dipartimento != null ? dipartimento : null;
	}

	// Method to create
	public static String createNewDipartimento(String nomeDipartimento) {
		if (!transactionObj.isActive()) {
			transactionObj.begin();
		}

		Dipartimento newDipartimentoObj = new Dipartimento();
		newDipartimentoObj.setIdDipartimento(getMaxDipartimentoId());
		newDipartimentoObj.setNomeDipartimento(nomeDipartimento);
	        em.merge(newDipartimentoObj);
	        transactionObj.commit();
	
		return "ProvaHome.xhtml?faces-redirect=true";
	}

	// Method to delete
	public static String deleteDipartimentoById(int idDipartimento) {
		if (!transactionObj.isActive()) {
			transactionObj.begin();
		}

		Dipartimento deleteDipartimentoObj = new Dipartimento();
		if (deleteDipartimentoById(idDipartimento) != null) {
			deleteDipartimentoObj.setIdDipartimento(idDipartimento);
			em.remove(em.merge(deleteDipartimentoObj));
		}
		transactionObj.commit();
		return "ListaDipendente.xhtml?faces-redirect=true";
	}

	// Method to update
	public static String updateDipartimento(int idDipartimento, String nomeDipartimento) {
		 if (!transactionObj.isActive()) {
	            transactionObj.begin();
	        }
	 
	       
			if(isDipartimentoIdPresent(idDipartimento)) {
	            Query queryObj = em.createQuery("UPDATE Dipartimento s SET s.name=:name WHERE s.idDipartimento= :id");         
	            queryObj.setParameter("id", idDipartimento);
	            queryObj.setParameter("name", nomeDipartimento);
	            int updateCount = queryObj.executeUpdate();
	            em.clear();
	            if(updateCount > 0) {
	                System.out.println("Record For Id: " + idDipartimento + " Is Updated");
	            }
	        }
	        transactionObj.commit();
	        
	        FacesContext.getCurrentInstance().addMessage("editDipartimentoForm:idDipartimento", new FacesMessage("Dipartimento Record #" + idDipartimento + " Is Successfully Updated In Db"));
	        return "ListaDipendenti.xhtml";
	    }
	

	  //Fetch Maximum Id From The Database
    private static int getMaxDipartimentoId() {
        int maxDipartimentoId = 1;
        Query queryObj = em.createQuery("SELECT MAX(s.idDipartimento)+1 FROM Dipartimento s");
        if(queryObj.getSingleResult() != null) {
            maxDipartimentoId = (Integer) queryObj.getSingleResult();
        }
        return maxDipartimentoId;
    }
    
    
	// Fetch Particular Details On The Basis Of Id From The Database
	private static boolean isDipartimentoIdPresent(int idDipartimento) {
		boolean idResult = false;
		Query queryObj = em.createQuery("SELECT s FROM Dipartimento s WHERE s.idDipartimento = :id");
		queryObj.setParameter("id", idDipartimento);
		Dipartimento selectedSchoolId = (Dipartimento) queryObj.getSingleResult();
		if (selectedSchoolId != null) {
			idResult = true;
		}
		return idResult;
	}

}
