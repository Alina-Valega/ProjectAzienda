package com.rextart.azienda.dao.impl;


import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.rextart.azienda.dao.DipendenteDao;
import com.rextart.azienda.entity.Dipendente;
import jakarta.persistence.Query;

public class DipendenteDaoImpl implements DipendenteDao {

	private static final String PERSISTENCE_UNIT_NAME = "Azienda";
	private static EntityManager em = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME).createEntityManager();
	public static EntityTransaction transactionObj = em.getTransaction();

	  // Method To Fetch All Dipendenti From The Database
    @SuppressWarnings("unchecked")
    public  List getAllDipendentiDetails() {
        Query queryObj = (Query) em.createNamedQuery("Dipendente.findAll",Dipendente.class);
        List dipendenteList = queryObj.getResultList();
        if (dipendenteList != null && dipendenteList.size() > 0) {           
            return dipendenteList;
        } else {
            return null;
        }
    }

	// Method to create
	public static String createNewDipendente(String nomeDipendente, String cognomeDipendente, Date dataAssunzione, float salario) {
		if (!transactionObj.isActive()) {
			transactionObj.begin();
		}

		Dipendente newDipendenteObj = new Dipendente();
		newDipendenteObj.setIdDipendente(getMaxDipendenteId());
		newDipendenteObj.setNomeDipendente(nomeDipendente);
		newDipendenteObj.setCognomeDipendente(cognomeDipendente);
		newDipendenteObj.setDataAssunzione(dataAssunzione);
		newDipendenteObj.setSalario(salario);
		
        em.merge(newDipendenteObj);
        transactionObj.commit();
		transactionObj.commit();
		return "ProvaHome.xhtml?faces-redirect=true";
	}

	// method to delelte
	public static String deleteDipendente(int idDipendente) {
		if (!transactionObj.isActive()) {
			transactionObj.begin();
		}

		Dipendente deleteDipendenteObj = new Dipendente();
		if (isDipendenteIdPresent(idDipendente)) {
			deleteDipendenteObj.setIdDipendente(idDipendente);
			em.remove(em.merge(deleteDipendenteObj));
		}
		transactionObj.commit();
		return "ListaDipendent.xhtml?faces-redirect=true";
	}

	// method to update
	public static String updateDipendente(int idDipendente, String nomeDipendente, String cognomeDipendente, Date dataAssunzione, float salario) {
		 if (!transactionObj.isActive()) {
	            transactionObj.begin();
	        }
	 
	        if(isDipendenteIdPresent(idDipendente)) {
	            Query queryObj = (Query) em.createQuery("UPDATE Dipendente s SET s.name=:name WHERE s.idDipendente= :id");         
	            queryObj.setParameter("id", idDipendente);
	            queryObj.setParameter("nome", nomeDipendente);
	            queryObj.setParameter("cognome", cognomeDipendente);
	            queryObj.setParameter("dataAssunzione", dataAssunzione);
	            queryObj.setParameter("salario", salario);
	            int updateCount = queryObj.executeUpdate();
	            em.clear();
	            if(updateCount > 0) {
	                System.out.println("Record For Id: " + idDipendente + " Is Updated");
	            }
	        }
		transactionObj.commit();

		return "ProvaHome.xhtml";

	}

	// Fetch Particular Details On The Basis Of Id From The Database
	public static boolean isDipendenteIdPresent(int idDipendente) {
		boolean idResult = false;
		Query queryObj = (Query) em.createQuery("SELECT s FROM Dipendente s WHERE s.idDipendente = :id");
		queryObj.setParameter("id", idDipendente);
		Dipendente selectedIdDipendente = (Dipendente) queryObj.getSingleResult();
		if (selectedIdDipendente != null) {
			idResult = true;
		}
		return idResult;

	}
	
    // Helper Method 1 - Fetch Maximum School Id From The Database
    private static int getMaxDipendenteId() {
        int maxDipendenteId = 1;
        Query queryObj = (Query) em.createQuery("SELECT MAX(s.idDipendente)+1 FROM Dipendente s");
        if(queryObj.getSingleResult() != null) {
        	maxDipendenteId = (Integer) queryObj.getSingleResult();
        }
        return maxDipendenteId;
    }

	@Override
	public List<Dipendente> getAllDipendenti() {
		// TODO Auto-generated method stub
		return null;
	}

 

}
