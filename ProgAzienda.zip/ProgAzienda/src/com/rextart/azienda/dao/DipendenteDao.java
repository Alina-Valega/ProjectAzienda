package com.rextart.azienda.dao;

import java.util.Date;
import java.util.List;

import com.rextart.azienda.entity.Dipendente;

public interface DipendenteDao {

	public List<Dipendente> getAllDipendenti();

	public static String addNewDipendente(String nomeDipendente, String cognomeDipendente, float salario,
			Date dataAssunzione) {
		return null;
	}

	public static String updateDipendente(Integer idDipendente, String nomeDipendente, String cognomeDipendente,
			float salario, Date dataAssunzione) {
		return null;
	}

	public static String deleteDipendnete(int idDipendente) {
		return null;
	}

}
