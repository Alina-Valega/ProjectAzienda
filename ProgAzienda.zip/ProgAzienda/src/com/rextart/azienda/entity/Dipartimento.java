package com.rextart.azienda.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "dipartimento")
@NamedQuery(name = "Dipartimento.findAll", query = "SELECT s FROM Dipartimento s ")
public class Dipartimento implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_dipartimento", unique = true, nullable = false)
	private int idDipartimento;

	@Column(name = "nome_dipartimento", nullable = false, length = 120)
	private static String nomeDipartimento;

	//// @OneToMany(mappedBy= "dipartimento")
	// private List<Dipendente> dipendenti;
	//
	public int getIdDipartimento() {
		return idDipartimento;
	}

	public void setIdDipartimento(int idDipartimento) {
		this.idDipartimento = idDipartimento;
	}

	public static String getNomeDipartimento() {
		return nomeDipartimento;
	}

	public void setNomeDipartimento(String nomeDipartimento) {
		this.nomeDipartimento = nomeDipartimento;
	}

}
