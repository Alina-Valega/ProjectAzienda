package com.rextart.azienda.dao.impl;

import java.util.List;

import com.rextart.azienda.dao.DipendenteDao;
import com.rextart.azienda.entity.Dipendenti;

public class DipendentDaoImpl implements DipendenteDao{

	@Override
	public List<Dipendenti> getAllDipendenti() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Dipendenti getDipendente(int id_dipendente) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveDipendente(Dipendenti dipendente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDipendente(Dipendenti dipendente) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteDipendnete(Dipendenti dipendente) {
		// TODO Auto-generated method stub
		
	}

}
