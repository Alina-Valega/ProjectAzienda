package com.rextart.azienda.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityTransaction;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.NamedQuery;

@Entity
@Table(name="Dipartimento")
@NamedQuery(name="EntityManager.findAll", query="SELECT s FROM EntityManager s")
public class Dipartimento implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_dipartimento", unique=true, nullable=false)
	private Integer id_dipartimento;

	@Column(nullable=false, length=120)
	private String nome_dipartimento;
	
	public void EntityManager() {
	}

	public int getId_dipartimento() {
		return id_dipartimento;
	}
	
	public void setId_dipartimento(int id_dipartimento) {
		this.id_dipartimento = id_dipartimento;
	}

	public String getNome_dipartimento() {
		return nome_dipartimento;
	}

	public void setNome_dipartimento(String nome_dipartimento) {
		this.nome_dipartimento = nome_dipartimento;
	}

	
}
