package com.rextart.azienda.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NamedQuery;
import org.springframework.data.jpa.repository.Temporal;

import com.rextart.azienda.entity.Dipartimento;

@Entity
@Table(name="Dipendente")
@NamedQuery(name="EntityManager.findAll", query="SELECT d FROM Dipendente d order by d.id")

public class Dipendenti implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_dipendente", unique=true, nullable=false)
	private int idDipendente;
	
	@Column(nullable=false, length=120)
	private String nome_dipendente;
	
	@Column(nullable=false, length=120)
	private String cognome_dipendente;
	
	//@Temporal(TemporalType.DATE)
	@Column(nullable=false)
	private Date data_assunzione;
	
	@Column(nullable=false)
	private float salario;
	
	@OneToMany(targetEntity = Dipartimento.class,cascade = CascadeType.ALL)
	@JoinColumn(name ="id_dipartimento_fk", referencedColumnName = "id_dipendente ", nullable= false)
	private List<Dipartimento> dipartimento;
	
	
	public void EntityManager() {
	}

	public int getId_dipendente() {
		return idDipendente;
	}

	public void setId_dipendente(int id_dipendente) {
		this.idDipendente = id_dipendente;
	}

	public String getNome_dipendente() {
		return nome_dipendente;
	}

	public void setNome_dipendente(String nome_dipendente) {
		this.nome_dipendente = nome_dipendente;
	}

	public String getCognome_dipendente() {
		return cognome_dipendente;
	}

	public void setCognome_dipendente(String cognome_dipendente) {
		this.cognome_dipendente = cognome_dipendente;
	}

	public Date getData_assunzione() {
		return data_assunzione;
	}

	public void setData_assunzione(Date data_assunzione) {
		this.data_assunzione = data_assunzione;
	}

	public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		this.salario = salario;
	}

	
	
	
}